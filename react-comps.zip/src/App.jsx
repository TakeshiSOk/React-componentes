import { useState } from "react";

import Ejercicio1 from "./pages/Ejercicio1";
import Ejercicio2 from "./pages/Ejercicio2";
import Ejercicio3 from "./pages/Ejercicio3";
import Ejercicio4 from "./pages/Ejercicio4";
import Ejercicio5 from "./pages/Ejercicio5";
import Ejercicio6 from "./pages/Ejercicio6";
import Ejercicio7 from "./pages/Ejercicio7";
import Ejercicio8 from "./pages/Ejercicio8";
import Ejercicio9 from "./pages/Ejercicio9";

export default function App() {
  const [vista, setVista] = useState(1);

  const renderEjercicio = () => {
    switch (vista) {
      case 1: return <Ejercicio1 />;
      case 2: return <Ejercicio2 />;
      case 3: return <Ejercicio3 />;
      case 4: return <Ejercicio4 />;
      case 5: return <Ejercicio5 />;
      case 6: return <Ejercicio6 />;
      case 7: return <Ejercicio7 />;
      case 8: return <Ejercicio8 />;
      case 9: return <Ejercicio9 />;
      default: return <Ejercicio1 />;
    }
  };

  return (
    <div className="app">
      <h1>📚 Ejercicios React</h1>

      <div className="menu">
        {[1,2,3,4,5,6,7,8,9].map(num => (
          <button key={num} onClick={() => setVista(num)}>
            Ejercicio {num}
          </button>
        ))}
      </div>

      {[6, 8, 9].includes(vista) ? (
        <div>
          <h2>Ejercicio {vista}</h2>
          {renderEjercicio()}
        </div>
      ) : (
        <div className="card">
          <h2>Ejercicio {vista}</h2>
          {renderEjercicio()}
        </div>
      )}
    </div>
  );
}