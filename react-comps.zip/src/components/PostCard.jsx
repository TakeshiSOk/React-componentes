import "./PostCard.css";

function PostCard({ day, weekday, title, text }) {
  return (
    <div className="post-card">
      <div className="date-box">
        <span className="date-num">{day}</span>
        <span className="date-day">{weekday}</span>
      </div>
      <div className="post-body">
        <h2 className="post-title">{title}</h2>
        <p className="post-text">{text}</p>
      </div>
    </div>
  );
}

export default PostCard;