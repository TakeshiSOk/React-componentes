import "./Nav9.css";

const items = ["Lorem", "Ipsum", "Dolor", "Sit", "Amet"];

function Nav9({ active, onSelect }) {
  return (
    <nav className="nav9">
      {items.map(item => (
        <span
          key={item}
          className={`nav9-item ${active === item ? "active" : ""}`}
          onClick={() => onSelect(item)}
        >
          {item}
        </span>
      ))}
    </nav>
  );
}

export default Nav9;