import "./Footer9.css";

function Footer9() {
  const links = ["Inicio", "Privacidad", "Legal", "Ayuda", "Contacto", "FAQ", "Soporte"];
  return (
    <footer className="footer9">
      {links.map(l => (
        <span key={l} className="footer9-link">{l}</span>
      ))}
      <span className="footer9-copy">© Copyright Lorem ipsum</span>
    </footer>
  );
}

export default Footer9;