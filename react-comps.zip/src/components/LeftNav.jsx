import "./LeftNav.css";

function LeftNav({ selected, onSelect }) {
  return (
    <div className="left-nav">
      <button
        className={`left-nav-btn ${selected === "Workouts" ? "active" : ""}`}
        onClick={() => onSelect("Workouts")}
      >
        Workouts
      </button>
      <button
        className={`left-nav-btn ${selected === "Exercises" ? "active" : ""}`}
        onClick={() => onSelect("Exercises")}
      >
        Exercises
      </button>
    </div>
  );
}

export default LeftNav;