import "./Sidebar9Right.css";

function Sidebar9Right({ posts }) {
  return (
    <div className="sidebar9-right">
      <h4>Primera bland</h4>
      {posts.slice(0, 2).map((p, i) => (
        <div key={i} className={`sb9r-card ${i === 1 ? "highlight" : ""}`}>
          <p className="sb9r-title">{p.title}</p>
          <p className="sb9r-body">{p.body.substring(0, 80)}...</p>
          <span className="sb9r-link">Seguir leyendo...</span>
        </div>
      ))}
    </div>
  );
}

export default Sidebar9Right;