import "./PostTable.css";

function PostTable({ posts, onDelete }) {
  return (
    <div className="post-table-wrapper">
      <h2 className="post-table-title">Recent Posts</h2>
      <table className="post-table">
        <thead>
          <tr>
            <th>Date Posted</th>
            <th>Title</th>
            <th>Category</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {posts.map((post, i) => (
            <tr key={i}>
              <td>{post.date}</td>
              <td>{post.title}</td>
              <td>{post.category}</td>
              <td>
                <button className="delete-btn" onClick={() => onDelete(i)}>🗑</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default PostTable;