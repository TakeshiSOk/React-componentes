import "./Header9.css";

function Header9({ onSearch }) {
  return (
    <div className="header9">
      <span className="header9-logo">Logotipo</span>
      <input
        className="header9-search"
        placeholder="Buscar..."
        onChange={e => onSearch(e.target.value)}
      />
    </div>
  );
}

export default Header9;