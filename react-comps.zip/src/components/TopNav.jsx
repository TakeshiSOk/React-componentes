import "./TopNav.css";

function TopNav() {
  return (
    <div className="top-nav">
      <span>Personal Trainer</span>
      <span>Top Nav</span>
      <span>History</span>
    </div>
  );
}

export default TopNav;