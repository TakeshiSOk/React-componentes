import "./Sidebar9Left.css";

function Sidebar9Left({ posts, onSelect }) {
  const noticias = posts.slice(0, 4);
  const relacionadas = posts.slice(0, 3);

  return (
    <div className="sidebar9-left">
      <div className="sb9-section">
        <h4>Noticias</h4>
        <ul>
          {noticias.map((p, i) => (
            <li key={i} onClick={() => onSelect(p)}>{p.title}</li>
          ))}
        </ul>
      </div>
      <div className="sb9-section">
        <h4>Entradas relacionadas</h4>
        <ul>
          {relacionadas.map((p, i) => (
            <li key={i} onClick={() => onSelect(p)}>{p.title}</li>
          ))}
        </ul>
      </div>
      <div className="sb9-section">
        <h4>Publicidad</h4>
        <div className="sb9-ad">Espacio publicitario</div>
      </div>
    </div>
  );
}

export default Sidebar9Left;