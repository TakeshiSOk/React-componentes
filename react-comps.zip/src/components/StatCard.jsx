import "./StatCard.css";

function StatCard({ value, label, color }) {
  return (
    <div className="stat-card" style={{ backgroundColor: color }}>
      <div className="stat-value">{value}</div>
      <div className="stat-label">{label}</div>
    </div>
  );
}

export default StatCard;