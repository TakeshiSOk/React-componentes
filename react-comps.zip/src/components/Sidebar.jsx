import "./Sidebar.css";

const menu = ["Dashboard", "Hardware", "Software", "Issued Licenses", "Requests", "About"];

function Sidebar({ active, onSelect, requestCount }) {
  return (
    <div className="sidebar">
      <div className="sidebar-brand">Asset Management</div>
      <ul className="sidebar-menu">
        {menu.map(item => (
          <li
            key={item}
            className={`sidebar-item ${active === item ? "active" : ""}`}
            onClick={() => onSelect(item)}
          >
            {item}
            {item === "Requests" && requestCount > 0 && (
              <span className="badge">{requestCount} New</span>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Sidebar;