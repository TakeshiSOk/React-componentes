import "./SubNav.css";

function SubNav() {
  return (
    <div className="sub-nav">
      <div className="sub-nav-left">
        <span>🏠 Home</span>
        <span>+ New Workout</span>
        <span>+ New Exercise</span>
      </div>
      <div className="sub-nav-center">Sub Nav</div>
    </div>
  );
}

export default SubNav;