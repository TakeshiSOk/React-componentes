import "./MainContent9.css";

function MainContent9({ posts, search }) {
  const filtered = posts.filter(p =>
    p.title.toLowerCase().includes(search.toLowerCase()) ||
    p.body.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="main9">
      {filtered.length === 0 && (
        <p className="no-results">No se encontraron resultados.</p>
      )}
      {filtered.map((post, i) => (
        <div key={i} className="article9">
          <h2 className="article9-title">{post.title}</h2>
          <p className="article9-body">{post.body}</p>
          <span className="article9-link">Seguir leyendo...</span>
          <hr />
        </div>
      ))}
    </div>
  );
}

export default MainContent9;