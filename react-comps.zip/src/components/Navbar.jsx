import { useState } from "react";
import "./Navbar.css";

function Navbar() {
  const [dropdownOpen, setDropdownOpen] = useState(false);

  return (
    <nav className="navbar">
      <ul className="nav-list">
        <li className="nav-item">Home</li>
        <li
          className="nav-item"
          onMouseEnter={() => setDropdownOpen(true)}
          onMouseLeave={() => setDropdownOpen(false)}
        >
          Photos
          {dropdownOpen && (
            <ul className="dropdown">
              <li>Family</li>
              <li>Vacations</li>
            </ul>
          )}
        </li>
        <li className="nav-item">Videos</li>
        <li className="nav-item">Contact</li>
      </ul>
    </nav>
  );
}

export default Navbar;