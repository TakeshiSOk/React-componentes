import "./PieChart.css";

function PieChart({ data }) {
  const total = data.reduce((sum, d) => sum + d.value, 0);
  const colors = ["#4a90d9", "#7ed321", "#f5a623", "#d0d0d0"];

  let cumulative = 0;
  const slices = data.map((d, i) => {
    const start = (cumulative / total) * 360;
    cumulative += d.value;
    const end = (cumulative / total) * 360;
    return { ...d, start, end, color: colors[i] };
  });

  function describeArc(cx, cy, r, startAngle, endAngle) {
    const toRad = a => (a - 90) * (Math.PI / 180);
    const x1 = cx + r * Math.cos(toRad(startAngle));
    const y1 = cy + r * Math.sin(toRad(startAngle));
    const x2 = cx + r * Math.cos(toRad(endAngle));
    const y2 = cy + r * Math.sin(toRad(endAngle));
    const large = endAngle - startAngle > 180 ? 1 : 0;
    return `M ${cx} ${cy} L ${x1} ${y1} A ${r} ${r} 0 ${large} 1 ${x2} ${y2} Z`;
  }

  return (
    <div className="pie-wrapper">
      <svg width="160" height="160" viewBox="0 0 160 160">
        {slices.map((s, i) => (
          <path
            key={i}
            d={describeArc(80, 80, 70, s.start, s.end)}
            fill={s.color}
            stroke="white"
            strokeWidth="2"
          />
        ))}
        {slices.map((s, i) => {
          const mid = (s.start + s.end) / 2;
          const toRad = a => (a - 90) * (Math.PI / 180);
          const x = 80 + 45 * Math.cos(toRad(mid));
          const y = 80 + 45 * Math.sin(toRad(mid));
          return (
            <text key={i} x={x} y={y} textAnchor="middle" fill="white" fontSize="11" fontWeight="bold">
              {s.value}
            </text>
          );
        })}
      </svg>
      <div className="pie-legend">
        {data.map((d, i) => (
          <div key={i} className="legend-item">
            <span className="legend-dot" style={{ backgroundColor: colors[i] }} />
            {d.label}
          </div>
        ))}
      </div>
    </div>
  );
}

export default PieChart;