import "./BlogNav.css";

function BlogNav() {
  return (
    <nav className="blog-nav">
      <span className="blog-nav-brand">Material Blog</span>
      <div className="blog-nav-links">
        <span>🔑 Login</span>
        <span>🏠 Home</span>
        <span>⊞ Dashboard</span>
        <span>↩ LogOut</span>
      </div>
    </nav>
  );
}

export default BlogNav;