import { useState } from "react";

// IMPORTA IMÁGENES
import img1 from "../assets/africa.jpg";
import img2 from "../assets/america.jpg";
import img3 from "../assets/australia.jpg";

export default function Ejercicio4() {
  const [imagen, setImagen] = useState(img1);

  return (
    <div className="section">
      <h2>Selector de Imágenes</h2>

      <div className="botones">
        <button onClick={() => setImagen(img1)}>africa</button>
        <button onClick={() => setImagen(img2)}>america</button>
        <button onClick={() => setImagen(img3)}>australia</button>
      </div>

      <div className="preview">
        <img src={imagen} alt="imagen seleccionada" />
      </div>
    </div>
  );
}