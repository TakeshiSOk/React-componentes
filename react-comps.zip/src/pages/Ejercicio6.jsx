import { useState } from "react";
import TopNav from "../components/TopNav";
import SubNav from "../components/SubNav";
import LeftNav from "../components/LeftNav";
import "./Ejercicio6.css";

const initialData = {
  Workouts: ["Monday Run", "Upper Body", "Leg Day"],
  Exercises: ["Push Up", "Squat", "Plank"],
};

function Ejercicio6() {
  const [selected, setSelected] = useState("Workouts");
  const [data, setData] = useState(initialData);
  const [input, setInput] = useState("");

  function handleAdd() {
    if (!input) return;
    setData({ ...data, [selected]: [...data[selected], input] });
    setInput("");
  }

  function handleDelete(index) {
    setData({
      ...data,
      [selected]: data[selected].filter((_, i) => i !== index),
    });
  }

  return (
    <div className="ej6-page">
      <TopNav />
      <SubNav />
      <div className="ej6-body">
        <LeftNav selected={selected} onSelect={setSelected} />
        <div className="content-area">
          <h2 className="content-title">{selected}</h2>

          <div className="content-form">
            <input
              placeholder={`New ${selected.slice(0, -1)}...`}
              value={input}
              onChange={e => setInput(e.target.value)}
            />
            <button className="content-add-btn" onClick={handleAdd}>+ Add</button>
          </div>

          <ul className="content-list">
            {data[selected].map((item, i) => (
              <li key={i} className="content-item">
                {item}
                <button onClick={() => handleDelete(i)}>🗑</button>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}

export default Ejercicio6;