import { useState } from "react";
import Header9 from "../components/Header9";
import Nav9 from "../components/Nav9";
import Sidebar9Left from "../components/Sidebar9Left";
import MainContent9 from "../components/MainContent9";
import Sidebar9Right from "../components/Sidebar9Right";
import Footer9 from "../components/Footer9";
import "./Ejercicio9.css";

const allPosts = [
  {
    title: "Lorem ipsum dolor sit amet, consectetuer adipiscing elit",
    body: "Nullam et lacus, suscipit id, dapibus quis, condimentum ac, mus. Vivamus vestibulum, ipsum sollicitudin faucibus pharetra, dolor metus fringilla dui, vel aliquet pede leo tempor tortor. Vestibulum pulvinar urna et quam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nullam vel turpis vitae dui imperdiet laoreet. Quisque eget quam.",
  },
  {
    title: "Vivamus lobortis turpis ac ante fringilla faucibus",
    body: "Quisque eget ligula. Donec commodo, turpis vel venenatis sollicitudin, quam ante commodo justo, sed eleifend justo lectus quis sapien. Ut consequat libero eget est. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nullam dictum hendrerit feugiat.",
  },
  {
    title: "Maecenas aliquam dolor eget nulla",
    body: "Fusce arcu ipsum, tempor eget tincidunt at, imperdiet in mi. Sed fermentum cursus dolor. Aenean a diam. Phasellus feugiat. Donec tempor dignissim sem.",
  },
  {
    title: "Fusce tristique lorem id purus",
    body: "Pellentesque habitant morbi tristique senectus et netus et malesuada fames. Donec commodo turpis vel venenatis sollicitudin. Nullam vel turpis vitae dui.",
  },
];

function Ejercicio9() {
  const [search, setSearch]   = useState("");
  const [navActive, setNavActive] = useState("Lorem");

  return (
    <div className="ej9-page">
      <Header9 onSearch={setSearch} />
      <Nav9 active={navActive} onSelect={setNavActive} />
      <div className="ej9-body">
        <Sidebar9Left posts={allPosts} onSelect={() => {}} />
        <MainContent9 posts={allPosts} search={search} />
        <Sidebar9Right posts={allPosts} />
      </div>
      <Footer9 />
    </div>
  );
}

export default Ejercicio9;