export default function Ejercicio2() {
  return (
    <div className="section">
      <div className="header2">Cabecera</div>

      <div className="layout">
        <div className="menu">Menú</div>

        <div className="contenido">
          <h3>Contenido</h3>
          <p>
            Aquí va el contenido principal de la página. Este es el centro del layout.
          </p>
        </div>

        <div className="lateral">Lateral</div>
      </div>

      <div className="footer2">Pie de página</div>
    </div>
  );
}