import { useState } from "react";
import Navbar from "../components/Navbar";
import PostCard from "../components/PostCard";
import "./Ejercicio5.css";

function Ejercicio5() {
  const [posts, setPosts] = useState([
    { day: 23, weekday: "Friday", title: "Title Post", text: "This is the text of my first post" },
  ]);

  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState("");
  const [text, setText] = useState("");

  function handleAdd() {
    if (!title || !text) return;
    const now = new Date();
    const days = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
    setPosts([...posts, {
      day: now.getDate(),
      weekday: days[now.getDay()],
      title,
      text,
    }]);
    setTitle("");
    setText("");
    setShowForm(false);
  }

  function handleDelete(index) {
    setPosts(posts.filter((_, i) => i !== index));
  }

  return (
    <div>
      <Navbar />
      <div className="page-content">
        <button className="add-btn" onClick={() => setShowForm(!showForm)}>
          + New Post
        </button>

        {showForm && (
          <div className="post-form">
            <input
              placeholder="Title"
              value={title}
              onChange={e => setTitle(e.target.value)}
            />
            <textarea
              placeholder="Write your post..."
              value={text}
              onChange={e => setText(e.target.value)}
            />
            <button className="save-btn" onClick={handleAdd}>Save</button>
          </div>
        )}

        <div className="posts-list">
          {posts.map((post, i) => (
            <div key={i} className="post-wrapper">
              <PostCard
                day={post.day}
                weekday={post.weekday}
                title={post.title}
                text={post.text}
              />
              <button className="delete-btn" onClick={() => handleDelete(i)}>🗑</button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Ejercicio5;