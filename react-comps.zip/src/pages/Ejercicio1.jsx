export default function Ejercicio1() {
  return (
    <div className="section">
      <div className="header">Hip & Happenin' Headline</div>

      <div className="row">
        <div className="box contact">Contact</div>

        <div className="box center">
          <h3>Where It's At</h3>
          <p>
            Este es un ejemplo de contenido bien organizado con React.
          </p>
        </div>

        <div className="box news">News</div>
      </div>

      <div className="footer">The small print</div>
    </div>
  );
}