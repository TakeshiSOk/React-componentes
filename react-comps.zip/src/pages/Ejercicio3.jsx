import { useState } from "react";

// IMPORTA TUS IMÁGENES
import img1 from "../assets/img1.jpg";
import img2 from "../assets/img2.jpg";
import img3 from "../assets/img3.jpg";

export default function Ejercicio3() {
  const [imagen, setImagen] = useState(img1);

  return (
    <div className="section">
      <h2>Galería</h2>

      <div className="galeria">
        <div className="miniaturas">
          <img src={img1} onClick={() => setImagen(img1)} />
          <img src={img2} onClick={() => setImagen(img2)} />
          <img src={img3} onClick={() => setImagen(img3)} />
        </div>

        <div className="preview">
          <img src={imagen} alt="preview" />
        </div>
      </div>
    </div>
  );
}