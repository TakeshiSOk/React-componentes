import { useState } from "react";
import BlogNav from "../components/BlogNav";
import PostTable from "../components/PostTable";
import "./Ejercicio7.css";

function Ejercicio7() {
  const [posts, setPosts] = useState([
    { date: "1/5/2018", title: "Post One",   category: "Web Development" },
    { date: "1/5/2018", title: "Post Two",   category: "Android Development" },
    { date: "1/5/2018", title: "Post Three", category: "iOS Development" },
  ]);

  const [showForm, setShowForm] = useState(false);
  const [title, setTitle]       = useState("");
  const [category, setCategory] = useState("");

  function handleAdd() {
    if (!title || !category) return;
    const today = new Date().toLocaleDateString("en-US");
    setPosts([...posts, { date: today, title, category }]);
    setTitle("");
    setCategory("");
    setShowForm(false);
  }

  function handleDelete(index) {
    setPosts(posts.filter((_, i) => i !== index));
  }

  return (
    <div>
      <BlogNav />
      <div className="ej7-content">
        <button className="add-post-btn" onClick={() => setShowForm(!showForm)}>
          + Add Post
        </button>

        {showForm && (
          <div className="post-form">
            <input
              placeholder="Title"
              value={title}
              onChange={e => setTitle(e.target.value)}
            />
            <input
              placeholder="Category"
              value={category}
              onChange={e => setCategory(e.target.value)}
            />
            <button className="submit-btn" onClick={handleAdd}>Save</button>
          </div>
        )}

        <PostTable posts={posts} onDelete={handleDelete} />
      </div>
    </div>
  );
}

export default Ejercicio7;