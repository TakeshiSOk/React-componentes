import { useState } from "react";
import Sidebar from "../components/Sidebar";
import StatCard from "../components/StatCard";
import PieChart from "../components/PieChart";
import "./Ejercicio8.css";

const initialRequests = [
  { id: 1, item: "Dell Monitor", status: "Pending" },
  { id: 2, item: "USB Hub",      status: "Pending" },
];

const initialHardware = [
  { id: 1, name: "Laptop Dell", category: "Laptops",  status: "Assigned" },
  { id: 2, name: "Monitor LG",  category: "Monitors", status: "In repair" },
  { id: 3, name: "Mouse",       category: "Peripherals", status: "Ordered" },
];

function Ejercicio8() {
  const [active, setActive]       = useState("Dashboard");
  const [requests, setRequests]   = useState(initialRequests);
  const [hardware, setHardware]   = useState(initialHardware);
  const [newReq, setNewReq]       = useState("");
  const [newHW, setNewHW]         = useState({ name: "", category: "", status: "Pending" });

  const pendingCount = requests.filter(r => r.status === "Pending").length;

  const pieData = [
    { label: "Assigned",  value: hardware.filter(h => h.status === "Assigned").length  || 0 },
    { label: "In repair", value: hardware.filter(h => h.status === "In repair").length || 0 },
    { label: "Ordered",   value: hardware.filter(h => h.status === "Ordered").length   || 0 },
    { label: "Pending",   value: hardware.filter(h => h.status === "Pending").length   || 0 },
  ].filter(d => d.value > 0);

  function addRequest() {
    if (!newReq) return;
    setRequests([...requests, { id: Date.now(), item: newReq, status: "Pending" }]);
    setNewReq("");
  }

  function deleteRequest(id) {
    setRequests(requests.filter(r => r.id !== id));
  }

  function approveRequest(id) {
    setRequests(requests.map(r => r.id === id ? { ...r, status: "Approved" } : r));
  }

  function addHardware() {
    if (!newHW.name || !newHW.category) return;
    setHardware([...hardware, { id: Date.now(), ...newHW }]);
    setNewHW({ name: "", category: "", status: "Pending" });
  }

  function deleteHardware(id) {
    setHardware(hardware.filter(h => h.id !== id));
  }

  function renderContent() {
    switch (active) {
      case "Dashboard":
        return (
          <div>
            <div className="stat-row">
              <StatCard value={pendingCount}        label="Requests Pending" color="#a78bfa" />
              <StatCard value={hardware.length}     label="Licenses Issued"  color="#34d399" />
            </div>
            <div className="section">
              <h3>Statistics by Hardware Status</h3>
              {pieData.length > 0
                ? <PieChart data={pieData} />
                : <p className="empty">No hardware data yet.</p>
              }
            </div>
            <div className="section">
              <h3>Statistics by Hardware Category</h3>
              <table className="dash-table">
                <thead><tr><th>Category</th><th>Count</th></tr></thead>
                <tbody>
                  {[...new Set(hardware.map(h => h.category))].map(cat => (
                    <tr key={cat}>
                      <td>{cat}</td>
                      <td>{hardware.filter(h => h.category === cat).length}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );

      case "Hardware":
        return (
          <div>
            <h2>Hardware</h2>
            <div className="form-row">
              <input placeholder="Name"     value={newHW.name}     onChange={e => setNewHW({...newHW, name: e.target.value})} />
              <input placeholder="Category" value={newHW.category} onChange={e => setNewHW({...newHW, category: e.target.value})} />
              <select value={newHW.status} onChange={e => setNewHW({...newHW, status: e.target.value})}>
                <option>Assigned</option>
                <option>In repair</option>
                <option>Ordered</option>
                <option>Pending</option>
              </select>
              <button className="btn-add" onClick={addHardware}>+ Add</button>
            </div>
            <table className="dash-table">
              <thead><tr><th>Name</th><th>Category</th><th>Status</th><th></th></tr></thead>
              <tbody>
                {hardware.map(h => (
                  <tr key={h.id}>
                    <td>{h.name}</td>
                    <td>{h.category}</td>
                    <td><span className={`status-badge ${h.status.replace(" ","-").toLowerCase()}`}>{h.status}</span></td>
                    <td><button className="btn-del" onClick={() => deleteHardware(h.id)}>🗑</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );

      case "Requests":
        return (
          <div>
            <h2>Requests</h2>
            <div className="form-row">
              <input placeholder="New request item..." value={newReq} onChange={e => setNewReq(e.target.value)} />
              <button className="btn-add" onClick={addRequest}>+ Add</button>
            </div>
            <table className="dash-table">
              <thead><tr><th>Item</th><th>Status</th><th></th></tr></thead>
              <tbody>
                {requests.map(r => (
                  <tr key={r.id}>
                    <td>{r.item}</td>
                    <td><span className={`status-badge ${r.status.toLowerCase()}`}>{r.status}</span></td>
                    <td>
                      {r.status === "Pending" && (
                        <button className="btn-approve" onClick={() => approveRequest(r.id)}>✓</button>
                      )}
                      <button className="btn-del" onClick={() => deleteRequest(r.id)}>🗑</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );

      default:
        return <div className="empty-section"><h2>{active}</h2><p>Section coming soon.</p></div>;
    }
  }

  return (
    <div className="ej8-layout">
      <Sidebar active={active} onSelect={setActive} requestCount={pendingCount} />
      <div className="ej8-main">
        {renderContent()}
      </div>
    </div>
  );
}

export default Ejercicio8;